	<!-- begin of "footer.php" import (opened at <html><body><div id="page">) -->
	
	</div>
	
	<div id="footer"><a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a></div>
</body>
</html>