<!-- Menu bar php file -->
<div class="link"><a href="#">home</a></div>
<div class="link"><a href="#">about</a></div>
<div class="link"><a href="#">portfolio</a></div>
<div class="link"><a href="#">prices</a></div>
<div class="link"><a href="#">products</a></div>
<div class="link"><a href="#">faq</a></div>
<div class="link"><a href="#">contact</a></div>