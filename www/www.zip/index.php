<?php include('header.php');?>

		
<?php include('status.php');?>
        <!--<div class="contentTitle"><h1>Template Usage</h1></div>
        <div class="contentText">
          <p>You may use this template on any site, anywhere, for free just please leave the link back to me in the footer. This template validates XHTML Strict 1.0, CSS Validates as well; enjoy :) </p>
          <p>&nbsp;</p>
          <p>Remember the early days when the Internet was all black and white, this is a throwback to those days. In all seriousness, I made this template because it was based on an earlier design that many found useful. Plus I've always had a thing for creating designs on the web with zero color, I guess it is an 'off the beaten path type deal'.</p>
          <p>&nbsp;</p>
          <p>I should also mention that this template has some updates (err... advantages) over the previous designs... this one uses h1 and h2 tags in the header for better SEO results, and has new image rollovers for the naviagation.</p>
          <p>&nbsp;</p>
          <p><a href="index.html">(read more)</a></p>
        </div>
        <div class="contentTitle"><h1>Another Title Goes Here!</h1></div>
        <div class="contentText">
          <p>This particular template goes not have a naviagation panel; it was intended for simple sites.   I am also making a version of this template with navigation, check out <a href="http://www.bryantsmith.com">BryantSmith.com</a> to get it.</p>
          <p>&nbsp;</p>
          <p><a href="index.html">(read more)</a></p>
        </div>
        <div class="contentTitle"><h1>Yet Another?</h1></div>
        <div class="contentText">Each title is an H1 tag, so choose them carefully :)</div>-->

<?php include('footer.php');?>		
<!--
	</div>
	
	<div id="footer"><a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a></div>
</body>
</html>
-->