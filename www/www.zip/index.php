 <!--
Design by Bryant Smith
http://www.bryantsmith.com
http://www.aszx.net
email: templates [-at-] bryantsmith [-dot-] com
Released under Creative Commons Attribution 2.5 Generic.  In other words, do with it what you please; but please leave the link if you'd be so kind :)

Name       : A Farewell to Colors
Description: One column, with top naviagation
Version    : 1.0
Released   : 20081230

20131031: Edit to "E-Bio web interface"
-->


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="files/style.css" />
<title>E-Bio</title>
</head>

<body>
    <div id="page">
		<div id="header">
			<h1>E-Bio web interface</h1>
            <!--<h2>An old school, black and white template created by Bryant Smith.</h2>-->
		</div>
		
		<div id="bar">
			<?php include('bar.php');?>
        	<!--<div class="link"><a href="#">home</a></div>
            <div class="link"><a href="#">about</a></div>
            <div class="link"><a href="#">portfolio</a></div>
            <div class="link"><a href="#">prices</a></div>
            <div class="link"><a href="#">products</a></div>
            <div class="link"><a href="#">faq</a></div>
            <div class="link"><a href="#">contact</a></div>-->
		</div>
		
		<?php include('status.php');?>
        <!--<div class="contentTitle"><h1>Template Usage</h1></div>
        <div class="contentText">
          <p>You may use this template on any site, anywhere, for free just please leave the link back to me in the footer. This template validates XHTML Strict 1.0, CSS Validates as well; enjoy :) </p>
          <p>&nbsp;</p>
          <p>Remember the early days when the Internet was all black and white, this is a throwback to those days. In all seriousness, I made this template because it was based on an earlier design that many found useful. Plus I've always had a thing for creating designs on the web with zero color, I guess it is an 'off the beaten path type deal'.</p>
          <p>&nbsp;</p>
          <p>I should also mention that this template has some updates (err... advantages) over the previous designs... this one uses h1 and h2 tags in the header for better SEO results, and has new image rollovers for the naviagation.</p>
          <p>&nbsp;</p>
          <p><a href="index.html">(read more)</a></p>
        </div>
        <div class="contentTitle"><h1>Another Title Goes Here!</h1></div>
        <div class="contentText">
          <p>This particular template goes not have a naviagation panel; it was intended for simple sites.   I am also making a version of this template with navigation, check out <a href="http://www.bryantsmith.com">BryantSmith.com</a> to get it.</p>
          <p>&nbsp;</p>
          <p><a href="index.html">(read more)</a></p>
        </div>
        <div class="contentTitle"><h1>Yet Another?</h1></div>
        <div class="contentText">Each title is an H1 tag, so choose them carefully :)</div>-->
	</div>
	
	<div id="footer"><a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a></div>
</body>
</html>
